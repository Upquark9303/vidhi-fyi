// Main tabs + sub-tabs, with hash deep-linking
function activateTab(name){
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.toggle('active', b.dataset.tab===name));
  document.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active', p.id==='tab-'+name));
}
function activateSub(panel, scope){
  const container = scope.closest('.tab-panel') || document;
  container.querySelectorAll('.subtab-btn').forEach(b=>{
    // only affect buttons in the same subtabs group
    if(b.parentElement===scope) b.classList.toggle('active', b.dataset.subtab===panel);
  });
  container.querySelectorAll('.sub-panel').forEach(p=>{
    const key = p.id.replace(/^sub-/,'');
    // only toggle panels that belong to this group (match a button in this group)
    const belongs = [...scope.querySelectorAll('.subtab-btn')].some(b=>b.dataset.subtab===key);
    if(belongs) p.classList.toggle('active', key===panel);
  });
}
document.querySelectorAll('.tab-btn').forEach(b=>{
  b.addEventListener('click', ()=>{
    activateTab(b.dataset.tab);
    history.replaceState(null,'','#'+b.dataset.tab);
    window.scrollTo({top: document.querySelector('.tabs').offsetTop - 120, behavior:'smooth'});
  });
});
document.querySelectorAll('.subtabs').forEach(group=>{
  group.querySelectorAll('.subtab-btn').forEach(b=>{
    b.addEventListener('click', ()=>activateSub(b.dataset.subtab, group));
  });
});
document.querySelectorAll('[data-goto]').forEach(b=>{
  b.addEventListener('click', ()=>activateTab(b.dataset.goto));
});
// open from #hash on load
const h=(location.hash||'').replace('#','');
if(h && document.getElementById('tab-'+h)) activateTab(h);
// CV check: warn if assets missing (e.g. opened zip without extracting)
document.querySelectorAll('a[href*="CV-Mayatra-Vidhi.pdf"]').forEach(a=>{
  a.addEventListener('click', async (e)=>{
    try{
      const r = await fetch(a.getAttribute('href'), {method:'HEAD'});
      if(!r.ok){ e.preventDefault(); alert('CV file not found next to index.html.\nExtract the full website folder so website/assets/CV-Mayatra-Vidhi.pdf exists, then click again.'); }
    }catch(_){ /* file:// fetch may fail — let normal download proceed */ }
  });
});
