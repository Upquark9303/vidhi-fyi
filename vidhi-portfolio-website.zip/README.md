# Mayatra Vidhi — PhD Application Website

Simple static site (no build step). Best for PhD applications because professors can open one link and download the CV directly.

## Files
- `index.html` — all content
- `styles.css`, `script.js`
- `assets/` — CV, profile photo, poster, IEEE paper, award certificate

## Preview locally
Double-click `index.html`, or run:
```
cd website
python -m http.server 8000
```
Then open http://localhost:8000

## Put online (free, recommended for PhD applications)
Option A — GitHub Pages:
1. Create GitHub repo `vidhi-portfolio`, upload the `website/` contents to root.
2. Settings → Pages → Deploy from branch → `main` / root.
3. You get `https://<username>.github.io/vidhi-portfolio/` — put this link in your CV / emails.

Option B — Netlify Drop: drag the `website` folder onto https://app.netlify.com/drop

## To update CV later
Replace `assets/CV-Mayatra-Vidhi.pdf` with the new file (keep same name) — the Download buttons keep working.
